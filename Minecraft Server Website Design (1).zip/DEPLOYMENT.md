# Руководство по развертыванию PenTime

## Быстрый старт

### Локальная разработка

```bash
# 1. Установка зависимостей
npm install

# 2. Запуск dev сервера
npm run dev

# 3. Открыть в браузере
# http://localhost:5173
```

### Production сборка

```bash
# Создание production build
npm run build

# Результат будет в папке /dist
```

## Платформы для развертывания

### 1. Vercel (Рекомендуется)

**Преимущества:**
- Бесплатный план
- Автоматический деплой из Git
- CDN и оптимизация
- SSL сертификат

**Шаги:**
1. Создайте аккаунт на [vercel.com](https://vercel.com)
2. Подключите Git репозиторий
3. Выберите проект
4. Нажмите Deploy

**Настройки проекта:**
- Framework Preset: Vite
- Build Command: `npm run build`
- Output Directory: `dist`

### 2. Netlify

**Преимущества:**
- Бесплатный SSL
- Continuous deployment
- Формы (для обратной связи)

**Настройки:**
- Build command: `npm run build`
- Publish directory: `dist`

### 3. GitHub Pages

**Для статического хостинга:**

1. Установите пакет:
```bash
npm install --save-dev gh-pages
```

2. Добавьте в `package.json`:
```json
{
  "homepage": "https://yourusername.github.io/pentime",
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

3. Деплой:
```bash
npm run deploy
```

### 4. Cloudflare Pages

**Преимущества:**
- Глобальный CDN
- Неограниченная пропускная способность
- DDoS защита

**Настройки:**
- Build command: `npm run build`
- Build output: `dist`

## Настройка домена

### DNS записи

Для подключения собственного домена:

```
Type: A
Name: @
Value: [IP вашего хостинга]

Type: CNAME
Name: www
Value: [домен хостинга]
```

### SSL сертификат

Большинство платформ предоставляют бесплатный SSL через Let's Encrypt автоматически.

## Переменные окружения

Создайте файл `.env` для локальной разработки:

```env
# API endpoints
VITE_API_URL=https://api.pentime.ru
VITE_PAYMENT_API=https://payments.pentime.ru

# Minecraft server
VITE_SERVER_IP=pentime.minecraft.ru
VITE_SERVER_PORT=25565

# Analytics (опционально)
VITE_GA_ID=G-XXXXXXXXXX
```

**Важно:** Не коммитьте `.env` файл в Git!

## Оптимизация

### 1. Сжатие изображений

Используйте оптимизированные изображения:
- WebP формат для фотографий
- SVG для иконок
- Максимум 200KB на изображение

### 2. Lazy Loading

Компоненты уже настроены для ленивой загрузки.

### 3. Кэширование

Настройте кэширование в headers:

```
# Vercel (vercel.json)
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    }
  ]
}
```

## Мониторинг

### Google Analytics

Добавьте в `index.html`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### Sentry (мониторинг ошибок)

```bash
npm install @sentry/react
```

```javascript
// В App.tsx
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "YOUR_SENTRY_DSN",
  environment: "production",
});
```

## Безопасность

### 1. Защита от XSS

React автоматически экранирует контент, но будьте осторожны с `dangerouslySetInnerHTML`.

### 2. CORS настройки

Настройте CORS на backend:

```javascript
app.use(cors({
  origin: ['https://pentime.ru', 'https://www.pentime.ru'],
  credentials: true
}));
```

### 3. Rate Limiting

Для API запросов используйте rate limiting:

```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 минут
  max: 100 // максимум 100 запросов
});

app.use('/api/', limiter);
```

## CI/CD Pipeline

### GitHub Actions

Создайте `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '18'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build
        run: npm run build
        
      - name: Deploy to Vercel
        uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
```

## Резервное копирование

### База данных

```bash
# Автоматический бэкап (cron)
0 2 * * * mongodump --uri="mongodb://..." --out="/backup/$(date +\%Y\%m\%d)"
```

### Файлы

Используйте:
- AWS S3
- Backblaze B2
- Google Cloud Storage

## Масштабирование

### CDN

Используйте CDN для статических файлов:
- Cloudflare
- AWS CloudFront
- Fastly

### Load Balancing

Для высоких нагрузок:
- NGINX
- HAProxy
- AWS ELB

## Чек-лист перед запуском

- [ ] SSL сертификат установлен
- [ ] Домен настроен
- [ ] Analytics подключена
- [ ] Мониторинг ошибок настроен
- [ ] Резервное копирование настроено
- [ ] Все API ключи в переменных окружения
- [ ] Production build протестирован
- [ ] Мобильная версия проверена
- [ ] SEO мета-теги добавлены
- [ ] Favicon установлен
- [ ] robots.txt создан
- [ ] sitemap.xml создан

## Поддержка

При возникновении проблем:
- Проверьте логи на платформе хостинга
- Используйте инструменты разработчика браузера
- Проверьте консоль на ошибки

## Полезные ссылки

- [Vercel Documentation](https://vercel.com/docs)
- [Netlify Documentation](https://docs.netlify.com)
- [Vite Documentation](https://vitejs.dev/guide/)
- [React Documentation](https://react.dev)

---

**Дата создания:** Январь 2026  
**Версия:** 1.0.0

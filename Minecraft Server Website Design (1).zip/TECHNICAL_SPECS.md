# Техническая документация PenTime Website

## Архитектура

### Технологический стек

**Frontend:**
- React 18.3.1 (с хуками)
- TypeScript (для типизации)
- Tailwind CSS 4.0 (кастомная тема)
- Vite (сборщик и dev-сервер)

**UI библиотеки:**
- Radix UI (доступные компоненты)
- Lucide React (иконки)
- Sonner (toast уведомления)
- Motion (анимации)

**Состояние:**
- React useState (локальное состояние)
- Client-side navigation (без роутера)

## Структура компонентов

```
App.tsx (корневой компонент)
├── Header.tsx (навигация)
├── Pages/
│   ├── HomePage.tsx (главная)
│   ├── AboutPage.tsx (о проекте)
│   ├── ShopPage.tsx (магазин)
│   ├── RulesPage.tsx (правила)
│   ├── FAQPage.tsx (вопросы)
│   └── InfoPage.tsx (информация)
├── UI Components/
│   ├── FeatherIcon.tsx (лого)
│   ├── ParticleBackground.tsx (анимация)
│   ├── ScrollToTop.tsx (кнопка)
│   ├── CallToAction.tsx (CTA)
│   └── ...
└── Footer.tsx (подвал)
```

## Цветовая палитра

### Основные цвета

```css
/* Красный (Primary) */
--primary: #dc2626 (rgb 220, 38, 38)
--primary-hover: #ef4444
--primary-dark: #7f1d1d

/* Белый (Foreground) */
--foreground: #ffffff
--gray-light: #f3f3f5
--gray-medium: #a3a3a3

/* Черный (Background) */
--background: #0a0a0a
--background-card: #1a1a1a
--background-muted: #2a2a2a
```

### Градиенты

```css
/* Красный градиент */
from-red-600 to-red-700

/* Бело-красный */
from-white via-red-500 to-white

/* Фоновые градиенты */
from-red-950/20 to-black/40
```

## Адаптивные breakpoints

```css
/* Mobile First подход */
sm: 640px   /* Планшеты */
md: 768px   /* Маленькие ноутбуки */
lg: 1024px  /* Десктопы */
xl: 1280px  /* Большие экраны */
2xl: 1536px /* Ultra-wide */
```

## Типографика

### Шрифты

```css
/* Display (заголовки) */
font-family: 'Rajdhani', sans-serif;
font-weight: 400, 500, 600, 700;

/* Body (текст) */
font-family: 'Inter', sans-serif;
font-weight: 300, 400, 500, 600, 700, 800, 900;
```

### Размеры текста

```
h1: text-4xl md:text-5xl (36px / 48px)
h2: text-3xl md:text-4xl (30px / 36px)
h3: text-2xl (24px)
h4: text-xl (20px)
body: text-base (16px)
small: text-sm (14px)
```

## Производительность

### Метрики

**Целевые показатели:**
- First Contentful Paint: < 1.8s
- Time to Interactive: < 3.8s
- Lighthouse Score: > 90

**Оптимизации:**
- Lazy loading компонентов
- Code splitting
- Image optimization
- Минификация CSS/JS
- Tree shaking

### Bundle размер

```
Estimated bundle size:
- Vendor (React, UI libs): ~150KB (gzipped)
- App code: ~80KB (gzipped)
- Total: ~230KB (gzipped)
```

## Анимации

### Кастомные анимации

```css
/* Fade In */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Float */
@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-20px); }
}

/* Glow */
@keyframes glow {
  0%, 100% { box-shadow: 0 0 20px rgba(220, 38, 38, 0.5); }
  50% { box-shadow: 0 0 40px rgba(220, 38, 38, 0.8); }
}
```

### Motion библиотека

```javascript
// Пример использования
import { motion } from 'motion/react';

<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.5 }}
>
  Content
</motion.div>
```

## Навигация

### Client-side routing

```javascript
// Состояние текущей страницы
const [currentPage, setCurrentPage] = useState('home');

// Навигация
onNavigate('shop'); // переход на магазин
```

### Доступные страницы

- `home` - Главная
- `about` - О проекте
- `shop` - Магазин
- `rules` - Правила
- `faq` - FAQ
- `info` - Информация

## Формы и валидация

### Обратная связь

```javascript
// Footer.tsx
<form onSubmit={handleSubmit}>
  <Input name="name" required />
  <Input name="email" type="email" required />
  <Textarea name="message" required />
  <Button type="submit">Отправить</Button>
</form>
```

### Валидация

Использует нативную HTML5 валидацию:
- `required` - обязательное поле
- `type="email"` - проверка email
- `minLength`, `maxLength` - длина

## Интеграции

### Готово к интеграции

**Платежные системы:**
- UnitPay
- Enot.io
- ЮMoney
- QIWI
- Crypto

**Социальные сети:**
- Telegram (готовые ссылки)
- TikTok (готовые ссылки)
- Discord (подготовлено)
- VK (подготовлено)

**Аналитика:**
- Google Analytics (готово к подключению)
- Yandex Metrika (готово к подключению)

## API endpoints (будущие)

```javascript
// Статус сервера
GET /api/server/status
Response: {
  online: boolean,
  players: number,
  maxPlayers: number,
  version: string
}

// Создание заказа
POST /api/payment/create
Body: {
  role_id: string,
  payment_method: string,
  user_data: object
}
Response: {
  order_id: string,
  payment_url: string
}

// Webhook оплаты
POST /api/payment/webhook
Body: {
  order_id: string,
  status: string,
  custom_fields: object
}
```

## Безопасность

### Реализованные меры

- React экранирует XSS автоматически
- HTTPS only (в production)
- Content Security Policy ready
- CORS настройки (backend)

### Рекомендации

```javascript
// CSP Header
Content-Security-Policy: 
  default-src 'self'; 
  script-src 'self' 'unsafe-inline' https://trusted-cdn.com;
  style-src 'self' 'unsafe-inline';
  img-src 'self' data: https:;
```

## Доступность (A11y)

### Реализовано

- Семантический HTML
- ARIA атрибуты (через Radix UI)
- Keyboard navigation
- Screen reader поддержка
- Контраст цветов WCAG AA

### Тестирование

```bash
# Lighthouse audit
npm run build
npx serve dist
# Открыть DevTools > Lighthouse > Run audit
```

## SEO

### Мета-теги (рекомендуемые)

```html
<!-- index.html -->
<meta name="description" content="PenTime - Minecraft сервер с уникальными режимами">
<meta name="keywords" content="minecraft, сервер, pentime, креатив, выживание">
<meta property="og:title" content="PenTime - Minecraft Server">
<meta property="og:description" content="Присоединяйся к нашему сообществу">
<meta property="og:image" content="/og-image.png">
<meta name="twitter:card" content="summary_large_image">
```

## Тестирование

### Unit тесты (рекомендуется)

```bash
# Установка
npm install -D vitest @testing-library/react

# Запуск
npm run test
```

### E2E тесты (рекомендуется)

```bash
# Установка Playwright
npm install -D @playwright/test

# Запуск
npx playwright test
```

## Мониторинг

### Метрики для отслеживания

- **Производительность**: LCP, FID, CLS
- **Ошибки**: JavaScript errors, API failures
- **Пользователи**: Просмотры страниц, время на сайте
- **Конверсии**: Клики на "Купить", отправки форм

### Инструменты

- Google Analytics 4
- Sentry (ошибки)
- Vercel Analytics (production)

## Будущие улучшения

### Фаза 2

- [ ] Backend API
- [ ] Авторизация пользователей
- [ ] Личный кабинет
- [ ] История покупок
- [ ] Галерея скриншотов

### Фаза 3

- [ ] Админ-панель
- [ ] CMS для новостей
- [ ] Discord интеграция
- [ ] Промокоды
- [ ] Реферальная система

## Контакты разработки

**Дата создания:** Январь 2026  
**Версия:** 1.0.0  
**Статус:** Production Ready

---

Создано для проекта PenTime

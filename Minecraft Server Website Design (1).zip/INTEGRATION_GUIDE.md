# Руководство по интеграции платежных систем для PenTime

## Обзор

Сайт PenTime готов к интеграции с различными платежными системами для обработки покупок донат-привилегий.

## Рекомендуемые платежные системы

### 1. UnitPay
**Преимущества:**
- Низкие комиссии (от 3%)
- Поддержка множества способов оплаты
- Простая интеграция через API
- Автоматическое зачисление

**Интеграция:**
```javascript
// В файле /src/app/components/ShopPage.tsx
const handleUnitPayPayment = async (item) => {
  const params = {
    account: userAccount, // ID пользователя
    sum: item.price,
    desc: `Покупка роли ${item.name}`,
    // ... другие параметры
  };
  
  // Перенаправление на UnitPay
  window.location.href = `https://unitpay.ru/pay/YOUR_PROJECT_ID?${new URLSearchParams(params)}`;
};
```

### 2. Enot.io
**Преимущества:**
- Специализация на игровых проектах
- Интеграция с Discord
- Webhook для автоматической активации

**Интеграция:**
```javascript
const handleEnotPayment = async (item) => {
  const response = await fetch('https://enot.io/pay', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      merchant_id: 'YOUR_MERCHANT_ID',
      amount: item.price,
      order_id: generateOrderId(),
      custom_fields: {
        role: item.id,
        minecraft_username: username,
      }
    })
  });
  
  const data = await response.json();
  window.location.href = data.payment_url;
};
```

### 3. ЮMoney (YooMoney)
**Преимущества:**
- Популярность в России
- Надежность
- Простая интеграция

**Интеграция:**
```javascript
const handleYooMoneyPayment = (item) => {
  const form = document.createElement('form');
  form.method = 'POST';
  form.action = 'https://yoomoney.ru/quickpay/confirm.xml';
  
  const params = {
    receiver: 'YOUR_WALLET',
    quickpay_form: 'shop',
    targets: `Покупка роли ${item.name}`,
    sum: item.price,
    // ... другие параметры
  };
  
  Object.keys(params).forEach(key => {
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = key;
    input.value = params[key];
    form.appendChild(input);
  });
  
  document.body.appendChild(form);
  form.submit();
};
```

## Backend интеграция

Для полноценной работы магазина необходим backend-сервер:

### Рекомендуемый стек:
- Node.js + Express
- База данных (MongoDB или PostgreSQL)
- Система очередей для обработки платежей

### Пример структуры backend:

```javascript
// server.js
const express = require('express');
const app = express();

// Webhook для получения уведомлений об оплате
app.post('/api/payment/webhook', async (req, res) => {
  const { order_id, status, custom_fields } = req.body;
  
  if (status === 'success') {
    // Активация привилегии на Minecraft сервере
    await activateRole(custom_fields.minecraft_username, custom_fields.role);
    
    // Сохранение в базу данных
    await saveTransaction(order_id, custom_fields);
  }
  
  res.json({ success: true });
});

// Создание заказа
app.post('/api/payment/create', async (req, res) => {
  const { role_id, user_data } = req.body;
  
  const order = await createOrder({
    role_id,
    user_data,
    amount: getRolePrice(role_id),
  });
  
  res.json({ order_id: order.id });
});
```

## Интеграция с Minecraft сервером

### Вариант 1: RCON
```javascript
const Rcon = require('rcon-client').Rcon;

async function activateRole(username, role) {
  const rcon = await Rcon.connect({
    host: 'YOUR_SERVER_IP',
    port: 25575,
    password: 'YOUR_RCON_PASSWORD'
  });
  
  // Выполнение команды на сервере
  await rcon.send(`lp user ${username} parent add ${role}`);
  await rcon.end();
}
```

### Вариант 2: API плагин
Создайте плагин для вашего Minecraft сервера с REST API:

```java
// Пример Spring Boot endpoint
@PostMapping("/api/roles/activate")
public ResponseEntity<?> activateRole(@RequestBody RoleActivationRequest request) {
    Player player = Bukkit.getPlayer(request.getUsername());
    // Логика активации роли
    return ResponseEntity.ok().build();
}
```

## Безопасность

### Важные моменты:

1. **Проверка подписи платежей:**
```javascript
const crypto = require('crypto');

function verifySignature(data, signature, secret) {
  const hash = crypto
    .createHash('sha256')
    .update(data + secret)
    .digest('hex');
  
  return hash === signature;
}
```

2. **Хранение секретных ключей:**
- Используйте переменные окружения (.env)
- Никогда не коммитьте секретные ключи в Git

3. **Валидация данных:**
- Всегда проверяйте входящие данные
- Используйте библиотеки для валидации (joi, yup)

## Настройка текущего кода

В файле `/src/app/components/ShopPage.tsx` замените функцию `handlePurchase`:

```javascript
const handlePurchase = async () => {
  if (!selectedItem || !paymentMethod) {
    toast.error('Выберите способ оплаты');
    return;
  }

  try {
    // Создание заказа на backend
    const response = await fetch('/api/payment/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        role_id: selectedItem.id,
        payment_method: paymentMethod,
        user_data: {
          minecraft_username: getMinecraftUsername(), // Получить из формы
        }
      })
    });
    
    const { payment_url } = await response.json();
    
    // Перенаправление на оплату
    window.location.href = payment_url;
  } catch (error) {
    toast.error('Ошибка при создании заказа');
  }
};
```

## Тестирование

### Sandbox режимы:
- UnitPay: используйте тестовый режим в личном кабинете
- Enot.io: доступен демо-режим
- ЮMoney: тестовые платежи с возвратом

## Дополнительные функции

### 1. История покупок
Добавьте страницу с историей транзакций пользователя.

### 2. Промокоды
Реализуйте систему промокодов для скидок.

### 3. Email уведомления
Отправляйте подтверждения покупок на email.

## Контакты для поддержки

При возникновении вопросов по интеграции:
- UnitPay: https://help.unitpay.ru
- Enot.io: https://enot.io/support
- ЮMoney: https://yoomoney.ru/docs

---

**Важно:** Перед запуском в production обязательно протестируйте все платежные сценарии в sandbox-режиме!

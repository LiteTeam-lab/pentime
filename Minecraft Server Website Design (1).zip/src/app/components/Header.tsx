import { useState, useEffect } from 'react';
import { Menu, X, Home, Info, ShoppingBag, FileText, HelpCircle, Server, Shield } from 'lucide-react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { Button } from '@/app/components/ui/button';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { id: 'home', label: 'Главная', icon: Home },
    { id: 'about', label: 'О проекте', icon: Info },
    { id: 'shop', label: 'Магазин', icon: ShoppingBag },
    { id: 'rules', label: 'Правила', icon: FileText },
    { id: 'info', label: 'Информация', icon: Server },
    { id: 'faq', label: 'FAQ', icon: HelpCircle },
    { id: 'admin', label: 'Администрация', icon: Shield },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-black/80 backdrop-blur-lg border-b border-red-600/20'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Логотип */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 group"
          >
            <div className="relative">
              <FeatherIcon className="w-8 h-8 text-red-600 group-hover:text-red-500 transition-colors" />
              <div className="absolute inset-0 bg-red-600/20 blur-xl group-hover:bg-red-500/30 transition-all" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-red-600 via-white to-red-600 bg-clip-text text-transparent">
              PenTime
            </span>
          </button>

          {/* Desktop меню */}
          <nav className="hidden md:flex items-center gap-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    currentPage === item.id
                      ? 'bg-red-600 text-white'
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Mobile меню кнопка */}
          <button
            className="md:hidden p-2 text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile меню */}
        {isMobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-red-600/20">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-3 w-full text-left px-4 py-3 rounded-lg transition-all ${
                    currentPage === item.id
                      ? 'bg-red-600 text-white'
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        )}
      </div>
    </header>
  );
}
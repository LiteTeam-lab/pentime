import { Music, Heart, Clock, Play, Pause } from 'lucide-react';
import { useState } from 'react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { CallToAction } from '@/app/components/CallToAction';
import { Card } from '@/app/components/ui/card';

interface AboutPageProps {
  onNavigate?: (page: string) => void;
}

export function AboutPage({ onNavigate = () => {} }: AboutPageProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const totalDuration = 225; // 3:45 в секундах

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
    // В production здесь будет реальный аудио плеер
  };

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Заголовок */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 flex items-center justify-center gap-3">
            <FeatherIcon className="w-12 h-12 text-red-600" />
            О нашей вселенной
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent mx-auto" />
        </div>

        {/* Основной текст */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
          <p className="text-lg text-gray-300 leading-relaxed mb-6">
            Наш проект — это больше, чем мир. Это целая вселенная со своей собственной историей, 
            написанной не днями, а временем, и огромным, живым сообществом, которое с каждым 
            восходом солнца в игре становится только больше и сильнее.
          </p>
        </Card>

        {/* Гимн */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
          <div className="flex items-center gap-3 mb-6">
            <Music className="w-6 h-6 text-red-600" />
            <h2 className="text-2xl font-bold">Наш гимн — «Хранители Времени»</h2>
          </div>

          {/* Баннер для гимна */}
          <div className="relative w-full h-64 md:h-80 mb-6 bg-gradient-to-br from-red-900/30 to-black/50 border border-red-600/30 rounded-lg overflow-hidden group">
            {/* Placeholder для баннера */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <Music className="w-16 h-16 text-red-600/50 mx-auto mb-4" />
                <p className="text-gray-400">Баннер гимна PenTime</p>
              </div>
            </div>
            
            {/* Кнопка воспроизведения на баннере */}
            <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
              <button 
                onClick={togglePlay}
                className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-500 transition-all hover:scale-110 shadow-lg shadow-red-600/50"
              >
                {isPlaying ? <Pause className="w-10 h-10 text-white ml-1" /> : <Play className="w-10 h-10 text-white ml-2" />}
              </button>
            </div>
          </div>

          {/* Текст о гимне */}
          <p className="text-gray-300 mb-4">
            Наш гимн, наша история — песня «Хранители Времени» от автора PenTime. 
            Она — саундтрек о нашем пути и жизни.
          </p>          
          {/* Аудио прогресс */}
          <div className="bg-black/50 border border-red-600/30 rounded-lg p-4">
            <div className="flex items-center gap-4">
              <button className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-500 transition-colors" onClick={togglePlay}>
                {isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white ml-0.5" />}
              </button>
              <div className="flex-1">
                <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full w-0 bg-gradient-to-r from-red-600 to-red-400" style={{ width: `${(currentTime / totalDuration) * 100}%` }} />
                </div>
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(totalDuration)}</span>
                </div>
              </div>
            </div>
            <p className="text-center text-sm text-gray-500 mt-3">
              Хранители Времени — PenTime
            </p>
          </div>
        </Card>

        {/* История */}
        <div className="space-y-6">
          <Card className="p-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-red-600/10 rounded-lg">
                <Clock className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-3">Наше начало</h3>
                <p className="text-gray-300 leading-relaxed">
                  Когда-то мы были лишь горсткой мечтателей, случайно нашедших друг друга. 
                  Но с каждым часом, проведённым вместе, наша связь крепла, а мечта обретала форму. 
                  Мы росли, преодолевали трудности и достигли невероятных вершин, глядя на которые, 
                  мы чувствуем гордость.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-8 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-red-600/10 rounded-lg">
                <Heart className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-3">Сегодня</h3>
                <p className="text-gray-300 leading-relaxed">
                  Сегодня мы с радостью распахиваем двери для новых Пёрышек, делимся вдохновением, 
                  теплом и страстью к творчеству. Мы с благодарностью смотрим в прошлое — ведь именно 
                  те первые моменты, те первые соратники стали для нас прочными корнями, которые 
                  удержали нас в любой шторм и позволили устремиться к небесам.
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-red-600/10 rounded-lg">
                <FeatherIcon className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-3">Мы — Хранители Времени</h3>
                <p className="text-gray-300 leading-relaxed">
                  Наше призвание — хранить жизнь, беречь путь, укреплять дружбу и поддерживать веру в мечту этого мира и его людей.
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Информационная карточка */}
        <Card className="mt-12 p-8 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
          <div className="flex items-start gap-4">
            <Users className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-xl font-bold mb-3">Играть одному — скучно</h3>
              <p className="text-gray-300 leading-relaxed">
                У нас ты найдёшь друзей. Общие ивенты, помощь в квестах и тёплые посиделки — 
                здесь это в порядке вещей. Java или Bedrock — неважно. Важно, с кем.
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Call to action */}
      <CallToAction onNavigate={onNavigate} />
    </div>
  );
}

function Users(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}
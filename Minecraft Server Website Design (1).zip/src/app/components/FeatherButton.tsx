import { ReactNode } from 'react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { Button } from '@/app/components/ui/button';

interface FeatherButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'outline';
  className?: string;
  disabled?: boolean;
}

export function FeatherButton({
  children,
  onClick,
  variant = 'primary',
  className = '',
  disabled = false,
}: FeatherButtonProps) {
  const getVariantClasses = () => {
    switch (variant) {
      case 'primary':
        return 'bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white shadow-lg shadow-red-600/30';
      case 'secondary':
        return 'bg-gradient-to-r from-white to-gray-200 text-black hover:from-gray-100 hover:to-white shadow-lg shadow-white/20';
      case 'outline':
        return 'border-2 border-red-600/50 text-white hover:bg-red-600/10 hover:border-red-600';
      default:
        return '';
    }
  };

  return (
    <Button
      onClick={onClick}
      disabled={disabled}
      className={`group relative overflow-hidden transition-all duration-300 ${getVariantClasses()} ${className}`}
    >
      {/* Анимированное перо на hover */}
      <div className="absolute -left-12 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 group-hover:left-2 transition-all duration-300">
        <FeatherIcon className="w-4 h-4" />
      </div>
      
      {/* Контент */}
      <span className="relative z-10 transition-all duration-300 group-hover:translate-x-3">
        {children}
      </span>

      {/* Shine эффект */}
      <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
    </Button>
  );
}

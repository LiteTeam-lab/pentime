import { Send } from 'lucide-react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Textarea } from '@/app/components/ui/textarea';
import { toast } from 'sonner';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name');
    const email = formData.get('email');
    const message = formData.get('message');

    // Здесь будет интеграция с backend
    toast.success('Сообщение отправлено!', {
      description: 'Мы свяжемся с вами в ближайшее время.',
    });

    e.currentTarget.reset();
  };

  return (
    <footer className="relative bg-black border-t border-red-600/20 overflow-hidden">
      {/* Декоративный фон */}
      <div className="absolute inset-0 bg-gradient-to-b from-red-950/10 to-transparent pointer-events-none" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Социальные сети */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <FeatherIcon className="w-6 h-6 text-red-600" />
            Наши официальные соц сети
          </h3>
          <div className="flex flex-wrap gap-4">
            <a
              href="https://t.me/PenTime_House"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 rounded-lg transition-all transform hover:scale-105"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.64-.203-.658-.64.135-.954l11.566-4.458c.538-.196 1.006.128.832.941z" />
              </svg>
              Telegram канал
            </a>
            <a
              href="https://www.tiktok.com/@pentimehome"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-white to-gray-200 text-black hover:from-gray-100 hover:to-white rounded-lg transition-all transform hover:scale-105"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
              </svg>
              TikTok аккаунт
            </a>
          </div>
        </div>

        {/* Обратная связь */}
        <div className="mb-12 p-8 bg-gradient-to-br from-red-950/20 to-black/40 rounded-xl border border-red-600/20">
          <h3 className="text-2xl font-bold mb-6">Обратная связь</h3>
          <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-4">
            <div>
              <Input
                name="name"
                placeholder="Ваше имя"
                required
                className="bg-black/50 border-red-600/30 focus:border-red-600"
              />
            </div>
            <div>
              <Input
                name="email"
                type="email"
                placeholder="Email"
                required
                className="bg-black/50 border-red-600/30 focus:border-red-600"
              />
            </div>
            <div className="md:col-span-2">
              <Textarea
                name="message"
                placeholder="Сообщение"
                required
                rows={4}
                className="bg-black/50 border-red-600/30 focus:border-red-600 resize-none"
              />
            </div>
            <div className="md:col-span-2">
              <Button
                type="submit"
                className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 w-full md:w-auto"
              >
                <Send className="w-4 h-4 mr-2" />
                Отправить сообщение
              </Button>
            </div>
          </form>
        </div>

        {/* Footer bottom */}
        <div className="pt-8 border-t border-red-600/20 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <FeatherIcon className="w-6 h-6 text-red-600" />
            <span className="text-gray-400">© 2026 PenTime. Все права защищены.</span>
          </div>
          <div className="flex gap-4">
            <button
              onClick={() => onNavigate('rules')}
              className="text-gray-400 hover:text-white transition-colors"
            >
              Правила
            </button>
            <button
              onClick={() => onNavigate('info')}
              className="text-gray-400 hover:text-white transition-colors"
            >
              Информация
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { Server, Copy, Check, Gamepad2, CheckCircle, AlertCircle, BookOpen, Users, Sparkles, Wrench, Book, Clock } from 'lucide-react';
import { useState } from 'react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { Card } from '@/app/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { toast } from 'sonner';

export function InfoPage() {
  const [copiedIP, setCopiedIP] = useState(false);
  const [activeTab, setActiveTab] = useState('about-game');
  const [featuresTab, setFeaturesTab] = useState('roles');
  const serverIP = 'pentime.ru';

  const handleCopyIP = () => {
    navigator.clipboard.writeText(serverIP);
    setCopiedIP(true);
    toast.success('IP-адрес скопирован!');
    setTimeout(() => setCopiedIP(false), 2000);
  };

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Заголовок */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 flex items-center justify-center gap-3">
            <Server className="w-12 h-12 text-red-600" />
            Информация о сервере
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent mx-auto" />
        </div>

        {/* Вкладки */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8 bg-black/40 border border-red-600/20">
            <TabsTrigger 
              value="about-game"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white"
            >
              <Gamepad2 className="w-4 h-4 mr-2" />
              О игре
            </TabsTrigger>
            <TabsTrigger 
              value="about-features"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white"
            >
              <BookOpen className="w-4 h-4 mr-2" />
              О возможностях
            </TabsTrigger>
          </TabsList>

          {/* Панель "О игре" */}
          <TabsContent value="about-game" className="space-y-8">
            {/* IP-адрес сервера */}
            <Card className="p-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/30">
              <div className="text-center">
                <h2 className="text-2xl font-bold mb-4 flex items-center justify-center gap-2">
                  <FeatherIcon className="w-6 h-6 text-red-600" />
                  IP-адрес сервера
                </h2>
                <div className="inline-flex items-center gap-3 px-6 py-4 bg-black/50 border border-red-600/30 rounded-lg mb-4">
                  <code className="text-2xl font-mono text-red-400">{serverIP}</code>
                  <button
                    onClick={handleCopyIP}
                    className="p-2 hover:bg-red-600/20 rounded-lg transition-colors"
                  >
                    {copiedIP ? (
                      <Check className="w-5 h-5 text-green-500" />
                    ) : (
                      <Copy className="w-5 h-5 text-gray-400" />
                    )}
                  </button>
                </div>
                <p className="text-gray-400">Нажмите на иконку, чтобы скопировать</p>
              </div>
            </Card>

            {/* Версии */}
            <Card className="p-8 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
              <h2 className="text-2xl font-bold mb-6">Поддерживаемые версии</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-red-950/20 border border-red-600/20 rounded-lg">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full" />
                    <span className="font-bold">Java Edition</span>
                  </div>
                  <p className="text-gray-400">Версии 1.21 - 1.21.11</p>
                </div>
                <div className="p-4 bg-red-950/20 border border-red-600/20 rounded-lg">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full" />
                    <span className="font-bold">Bedrock Edition</span>
                  </div>
                  <p className="text-gray-400">Самые последние версии</p>
                </div>
              </div>
            </Card>

            {/* Инструкция */}
            <Card className="p-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Gamepad2 className="w-6 h-6 text-red-600" />
                Как начать играть
              </h2>
              
              <div className="space-y-6">
                {/* Шаг 1 */}
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-red-600 to-red-700 rounded-full flex items-center justify-center font-bold">
                    1
                  </div>
                  <div>
                    <h3 className="font-bold mb-2">Запустите Minecraft</h3>
                    <p className="text-gray-400">Откройте Minecraft Java Edition или Bedrock Edition</p>
                  </div>
                </div>

                {/* Шаг 2 */}
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-red-600 to-red-700 rounded-full flex items-center justify-center font-bold">
                    2
                  </div>
                  <div>
                    <h3 className="font-bold mb-2">Добавьте сервер</h3>
                    <p className="text-gray-400">Перейдите в раздел "Мультиплеер" и нажмите "Добавить сервер"</p>
                  </div>
                </div>

                {/* Шаг 3 */}
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-red-600 to-red-700 rounded-full flex items-center justify-center font-bold">
                    3
                  </div>
                  <div>
                    <h3 className="font-bold mb-2">Введите IP-адрес</h3>
                    <p className="text-gray-400">Скопируйте и вставьте: <code className="text-red-400">{serverIP}</code></p>
                  </div>
                </div>

                {/* Шаг 4 */}
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-red-600 to-red-700 rounded-full flex items-center justify-center font-bold">
                    4
                  </div>
                  <div>
                    <h3 className="font-bold mb-2">Подключайтесь и играйте!</h3>
                    <p className="text-gray-400">Нажмите "Готово" и подключитесь к серверу</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Дополнительная информация */}
            <Card className="p-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
              <h2 className="text-2xl font-bold mb-4">Важная информация</h2>
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-300">Java или Bedrock — неважно. Важно, с кем играть.</p>
                </div>
                <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-300">У нас ты найдёшь друзей и уютное комьюнити.</p>
                </div>
                <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-300">Общие ивенты, помощь в квестах и тёплые посиделки — это у нас в порядке вещей.</p>
                </div>
                <div className="flex items-start gap-3 p-3 bg-red-950/20 rounded-lg border-l-4 border-red-500">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-300">Перед началом игры обязательно ознакомьтесь с правилами сервера.</p>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Панель "О возможностях" */}
          <TabsContent value="about-features">
            <div className="space-y-6">
              {/* Навигация по категориям */}
              <Card className="p-4 bg-gradient-to-br from-black/60 to-red-950/20 border-red-600/20">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <button
                    onClick={() => setFeaturesTab('roles')}
                    className={`p-3 rounded-lg transition-all flex items-center justify-center gap-2 ${
                      featuresTab === 'roles'
                        ? 'bg-gradient-to-r from-red-600 to-red-700 text-white'
                        : 'bg-black/30 hover:bg-red-600/20 text-gray-400'
                    }`}
                  >
                    <Users className="w-4 h-4" />
                    <span className="text-sm font-semibold">Роли</span>
                  </button>
                  <button
                    onClick={() => setFeaturesTab('brewing')}
                    className={`p-3 rounded-lg transition-all flex items-center justify-center gap-2 ${
                      featuresTab === 'brewing'
                        ? 'bg-gradient-to-r from-red-600 to-red-700 text-white'
                        : 'bg-black/30 hover:bg-red-600/20 text-gray-400'
                    }`}
                  >
                    <Sparkles className="w-4 h-4" />
                    <span className="text-sm font-semibold">Пивоварение</span>
                  </button>
                  <button
                    onClick={() => setFeaturesTab('mechanics')}
                    className={`p-3 rounded-lg transition-all flex items-center justify-center gap-2 ${
                      featuresTab === 'mechanics'
                        ? 'bg-gradient-to-r from-red-600 to-red-700 text-white'
                        : 'bg-black/30 hover:bg-red-600/20 text-gray-400'
                    }`}
                  >
                    <Wrench className="w-4 h-4" />
                    <span className="text-sm font-semibold">Механики</span>
                  </button>
                  <button
                    onClick={() => setFeaturesTab('lore')}
                    className={`p-3 rounded-lg transition-all flex items-center justify-center gap-2 ${
                      featuresTab === 'lore'
                        ? 'bg-gradient-to-r from-red-600 to-red-700 text-white'
                        : 'bg-black/30 hover:bg-red-600/20 text-gray-400'
                    }`}
                  >
                    <Book className="w-4 h-4" />
                    <span className="text-sm font-semibold">Лор</span>
                  </button>
                </div>
              </Card>

              {/* Контент роли */}
              {featuresTab === 'roles' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold flex items-center gap-2">
                    <Users className="w-8 h-8 text-red-600" />
                    Роли и их возможности
                  </h2>

                  {/* Важное сообщение */}
                  <Card className="p-6 bg-gradient-to-br from-yellow-950/30 to-black/40 border-yellow-600/50">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-6 h-6 text-yellow-500 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-xl font-bold text-yellow-400 mb-3">Важно!</h3>
                        <p className="text-gray-300 leading-relaxed">
                          При заходе на сервер вы получаете роль "Странник". Спустя некоторое время, а также при соблюдении правил, вас могут повысить до статуса Вестник и так далее. Повышение происходит в автоматическом режиме(/menu) и зависит от нескольких факторов: проведенного времени на сервере, вклада в развитие сервера, участие в ивентах. Если вы считаете, что вам необходимо уже сейчас повысить статус, то можете связаться с администрацией.
                        </p>
                      </div>
                    </div>
                  </Card>

                  {/* Бесплатные роли */}
                  <Card className="p-6 bg-gradient-to-br from-green-600/10 via-black/40 to-emerald-900/10 border-green-600/30">
                    <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                      Бесплатные роли
                    </h3>
                    
                    <div className="space-y-4">
                      {[
                        {
                          name: 'Странник',
                          gradient: 'from-gray-500 to-gray-600',
                          commands: [
                            'Топ отыгранного времени /toponline',
                            'Топ по балансу /baltop',
                            'Топ по скиллами /skilltop',
                            'Сменить скин /skin',
                            'Аукцион /ah',
                            'Отправить жалобу /helper',
                          ]
                        },
                        {
                          name: 'Вестник',
                          gradient: 'from-blue-500 to-cyan-500',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Просматреть свои скиллы /skill',
                            'Выбрать свою работу /jobs',
                            'Выбрать своего питомца /pet',
                            'Сидеть, лежать, крутиться /sit /lay /spin',
                            'Скупщик /buyer',
                          ]
                        },
                        {
                          name: 'Часовщик',
                          gradient: 'from-cyan-500 to-teal-500',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Создать свой клан /clan',
                            'Телепортироваться на варп /warp',
                            'Подбросить монетку /coin',
                          ]
                        },
                        {
                          name: 'Оракул',
                          gradient: 'from-teal-500 to-green-500',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Включить режим инспектора /co i',
                            'Красться /crawl',
                            'Магический шар /ball',
                            'Кинуть кубик /dice',
                            'Объявление /do',
                            'Возможность ставить 1 точку дома /sethome',
                            'Возможность отправить запрос телепортации /tpa',
                          ]
                        },
                        {
                          name: 'Вековец',
                          gradient: 'from-green-500 to-lime-500',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Игнорировать игрока /ignore',
                            'Анонимное сообщение в чат /anon',
                            'Возможность ставить 2 точки дома /sethome',
                            'Отправить запрос на телепортацию к себе /tpahere',
                            'Открыть верстак /craft',
                          ]
                        },
                        {
                          name: 'Вечность',
                          gradient: 'from-lime-500 to-yellow-500',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Возможность ставить 3 точки дома /sethome',
                            'Открыть наковальню /anvil',
                            'Восстановить голод /feed',
                          ]
                        },
                        {
                          name: 'Фактум',
                          gradient: 'from-yellow-500 to-orange-500',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Возможность ставить 4 точки дома /sethome',
                            'Установить 2 точки варпа /setwarp',
                            'Вылечить себя /heal',
                            'Открыть эндерсундук /ec',
                          ]
                        },
                        {
                          name: 'Хроник',
                          gradient: 'from-orange-500 to-red-500',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Возможность ставить 5 точек дома /sethome',
                            'Установить 3 точки варпа /setwarp',
                            'Включить полёт /fly',
                            'Открыть эндерсундук /ec',
                          ]
                        },
                        {
                          name: 'Исток',
                          gradient: 'from-red-500 to-pink-500',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Скоро...',
                          ]
                        },
                      ].map((role, index) => (
                        <div key={index} className="p-4 bg-black/40 rounded-lg border border-green-600/20 hover:border-green-600/40 transition-all">
                          <h4 className={`text-xl font-bold mb-3 bg-gradient-to-r ${role.gradient} bg-clip-text text-transparent`}>
                            {role.name}
                          </h4>
                          <ul className="space-y-1.5">
                            {role.commands.map((cmd, cmdIdx) => (
                              <li key={cmdIdx} className="flex items-start gap-2 text-sm text-gray-300">
                                <span className="text-green-500 mt-0.5">•</span>
                                <span>{cmd}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </Card>

                  {/* Платные роли */}
                  <Card className="p-6 bg-gradient-to-br from-purple-600/10 via-black/40 to-pink-900/10 border-purple-600/30">
                    <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
                      Платные роли
                    </h3>
                    
                    <div className="space-y-4">
                      {[
                        {
                          name: 'Сновидец',
                          gradient: 'from-purple-500 to-violet-600',
                          commands: [
                            'Все команды Оракул',
                            'Возможность ставить 1 точку дома /sethome',
                            'Возможность отправить запрос телепортации /tpa',
                          ]
                        },
                        {
                          name: 'Провидец',
                          gradient: 'from-violet-500 to-blue-600',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Игнорировать игрока /ignore',
                            'Анонимное сообщение в чат /anon',
                            'Возможность ставить 2 точки дома /sethome',
                            'Отправить запрос на телепортацию к себе /tpahere',
                            'Открыть верстак /craft',
                          ]
                        },
                        {
                          name: 'Манускрипт',
                          gradient: 'from-blue-500 to-cyan-600',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Возможность ставить 4 точки дома /sethome',
                            'Установить 2 точки варпа /setwarp',
                            'Вылечить себя /heal',
                            'Открыть эндерсундук /ec',
                          ]
                        },
                        {
                          name: 'Скрижаль',
                          gradient: 'from-cyan-500 to-teal-600',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Возможность ставить 5 точек дома /sethome',
                            'Установить 3 точки варпа /setwarp',
                            'Включить полёт /fly',
                            'Открыть эндерсундук /ec',
                          ]
                        },
                        {
                          name: 'Небожитель',
                          gradient: 'from-teal-500 to-green-600',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Возможность ставить 5 точек дома /sethome',
                            'Установить 3 точки варпа /setwarp',
                            'Включить полёт /fly',
                            'Открыть эндерсундук /ec',
                          ]
                        },
                        {
                          name: 'Хрономант',
                          gradient: 'from-red-500 to-pink-600',
                          commands: [
                            'Все команды предыдущих рангов',
                            'Скоро...',
                          ]
                        },
                      ].map((role, index) => (
                        <div key={index} className="p-4 bg-black/40 rounded-lg border border-purple-600/20 hover:border-purple-600/40 transition-all">
                          <h4 className={`text-xl font-bold mb-3 bg-gradient-to-r ${role.gradient} bg-clip-text text-transparent`}>
                            {role.name}
                          </h4>
                          <ul className="space-y-1.5">
                            {role.commands.map((cmd, cmdIdx) => (
                              <li key={cmdIdx} className="flex items-start gap-2 text-sm text-gray-300">
                                <span className="text-purple-500 mt-0.5">•</span>
                                <span>{cmd}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </Card>
                </div>
              )}

              {/* Контент пивоварения */}
              {featuresTab === 'brewing' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold flex items-center gap-2">
                    <Sparkles className="w-8 h-8 text-red-600" />
                    Пивоварение PenTime
                  </h2>

                  <Card className="p-8 bg-gradient-to-br from-amber-950/20 to-black/40 border-amber-600/30">
                    <div className="flex items-center gap-3 mb-6">
                      <Sparkles className="w-6 h-6 text-amber-500" />
                      <h3 className="text-2xl font-bold text-amber-400">Уникальная система пивоварения</h3>
                    </div>
                    
                    <div className="space-y-4 text-gray-300">
                      <p className="leading-relaxed">
                        На сервере PenTime доступна расширенная система пивоварения, которая позволяет создавать не только стандартные зелья, но и уникальные напитки с особыми эффектами.
                      </p>
                      
                      <div className="p-4 bg-black/40 rounded-lg border border-amber-600/20">
                        <h4 className="font-bold text-amber-300 mb-3">Особенности:</h4>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                            <span>Более 50 уникальных рецептов напитков</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                            <span>Различная выдержка и качество напитков</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                            <span>Торговля напитками с другими игроками</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                            <span>Создание собственных брендов и этикеток</span>
                          </li>
                        </ul>
                      </div>

                      <div className="p-4 bg-amber-950/10 rounded-lg border-l-4 border-amber-500">
                        <p className="text-amber-200">
                          💡 Подробные рецепты и гайды по пивоварению доступны на сервере в специальном меню /brewing
                        </p>
                      </div>
                    </div>
                  </Card>

                  <Card className="p-6 bg-gradient-to-br from-black/40 to-amber-950/20 border-amber-600/20">
                    <h3 className="text-xl font-bold mb-4 text-amber-400">Скоро появится детальное руководство</h3>
                    <p className="text-gray-400">
                      Мы работаем над созданием полного руководства по пивоварению на PenTime. Следите за обновлениями!
                    </p>
                  </Card>
                </div>
              )}

              {/* Контент игровых механик */}
              {featuresTab === 'mechanics' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold flex items-center gap-2">
                    <Wrench className="w-8 h-8 text-red-600" />
                    Игровые механики
                  </h2>

                  <Card className="p-8 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
                    <div className="text-center">
                      <Clock className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                      <h3 className="text-2xl font-bold text-gray-500 mb-2">Скоро...</h3>
                      <p className="text-gray-500 italic">Информация появится в ближайшее время</p>
                    </div>
                  </Card>
                </div>
              )}

              {/* Контент лора */}
              {featuresTab === 'lore' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold flex items-center gap-2">
                    <Book className="w-8 h-8 text-red-600" />
                    Лор
                  </h2>

                  <Card className="p-8 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
                    <div className="text-center">
                      <Clock className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                      <h3 className="text-2xl font-bold text-gray-500 mb-2">Скоро...</h3>
                      <p className="text-gray-500 italic">Информация появится в ближайшее время</p>
                    </div>
                  </Card>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

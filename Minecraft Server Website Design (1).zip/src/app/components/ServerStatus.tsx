import { useState, useEffect } from 'react';
import { Server, Users, Clock } from 'lucide-react';
import { Card } from '@/app/components/ui/card';

export function ServerStatus() {
  const [status, setStatus] = useState({
    online: true,
    players: 0,
    maxPlayers: 100,
    uptime: '24/7',
  });

  useEffect(() => {
    // Симуляция получения статуса сервера
    // В production здесь будет реальный API запрос
    const interval = setInterval(() => {
      setStatus(prev => ({
        ...prev,
        players: Math.floor(Math.random() * 80) + 20,
      }));
    }, 30000); // Обновление каждые 30 секунд

    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="p-4 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className={`w-3 h-3 rounded-full ${status.online ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
          <div>
            <div className="text-sm font-semibold">Статус сервера</div>
            <div className="text-xs text-gray-400">{status.online ? 'Онлайн' : 'Оффлайн'}</div>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-red-600" />
            <span className="text-sm">{status.players}/{status.maxPlayers}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-red-600" />
            <span className="text-sm">{status.uptime}</span>
          </div>
        </div>
      </div>
    </Card>
  );
}

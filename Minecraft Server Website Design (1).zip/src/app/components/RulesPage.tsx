import { Shield, AlertCircle, MessageSquare, Server, Film, Users, CheckCircle } from 'lucide-react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { Card } from '@/app/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/app/components/ui/accordion';

export function RulesPage() {
  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Заголовок */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 flex items-center justify-center gap-3">
            <Shield className="w-12 h-12 text-red-600" />
            Кодекс PenTime
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent mx-auto mb-6" />
          
          <Card className="p-6 bg-red-950/30 border-red-600/50">
            <p className="text-xl font-bold flex items-center justify-center gap-2">
              <AlertCircle className="w-6 h-6 text-red-500" />
              НЕЗНАНИЕ ПРАВИЛ НЕ ОСВОБОЖДАЕТ ОТ ОТВЕТСТВЕННОСТИ
            </p>
          </Card>
        </div>

        {/* Философия */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <FeatherIcon className="w-6 h-6 text-red-600" />
            НАША ФИЛОСОФИЯ
          </h2>
          <div className="space-y-3 text-gray-300">
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p>Добро пожаловать в семью! Наш проект — это пространство для дружбы, уважения и совместного творчества.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p>Наша главная ценность — люди и их комфорт.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p>Каждое правило здесь создано для защиты этой ценности и поддержания здоровой атмосферы.</p>
            </div>
          </div>
        </Card>

        {/* Главный принцип */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-yellow-950/20 to-black/40 border-yellow-600/30">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <span className="text-yellow-500">★</span>
            ГЛАВНОЕ ПРАВИЛО — ПРАВИЛО /STOP
          </h2>
          <div className="space-y-3 text-gray-300">
            <div className="flex items-start gap-3 p-3 bg-yellow-950/10 rounded-lg border-l-4 border-yellow-500">
              <CheckCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
              <p className="text-yellow-200">«Шутка перестает быть шуткой, когда объекту шутки не смешно».</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
              <p>Если вам неприятно, неуютно или вы хотите прекратить общение/действие в ваш адрес, немедленно используйте команду /stop или /стоп.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
              <p>Продолжение действий после полученной команды /stop расценивается как прямое оскорбление и нарушение границ.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
              <p>Спам или злоупотребление командой /stop (например, ее использование для срыва обычного общения, не являющегося нарушением) также является нарушением.</p>
            </div>
            <div className="mt-4 p-3 bg-red-950/30 rounded-lg border border-red-600/30">
              <p className="text-sm">✎ Наказание за оба нарушения (игнорирование и спам командой): Мут 1-2 часа + Варн (система действует для ВСЕХ участников).</p>
            </div>
          </div>
        </Card>

        {/* Основы сообщества */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
          <h2 className="text-2xl font-bold mb-4">ОСНОВЫ СООБЩЕСТВА</h2>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg border-l-4 border-red-500">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-gray-300 font-semibold">Чистка участников проходит в последний день каждого месяца.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg border-l-4 border-red-500">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-gray-300 font-semibold">Минимальная активность в чате Telegram: 1000 сообщений в месяц. Это помогает поддерживать живое общение. (В среднем это 33 сообщения в день или 230+ в неделю).</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg border-l-4 border-red-500">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-gray-300 font-semibold">Испытательный срок: 2 дня для новых участников. Требование: написать 300 сообщений в чате за этот срок.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-gray-300">Важно: Даже после успешного прохождения испытательного срока участник не должен полностью пропадать из чата. Если в течение следующих 6 дней после испытательного срока активность остается на уровне ~300 сообщений и не показывает роста к требуемому минимуму, это является основанием для исключения.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg border-l-4 border-red-500">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-gray-300 font-semibold">Минимальная активность на сервере Minecraft: Не менее 1 игрового дня (24 часа) наигрыша в месяц. Активность проверяется через игровую статистику. Цель — быть частью игрового мира, а не только чата.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-gray-300">Право на рест (временный перерыв) появляется после 7 дней постоянного пребывания в проекте.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-gray-300">Запрос на рест (1-2 недели) отправляется только Владельцу проекта.</p>
            </div>
          </div>
        </Card>

        {/* Культура общения */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <MessageSquare className="w-6 h-6 text-red-600" />
            КУЛЬТУРА ОБЩЕНИЯ В ЧАТЕ (TELEGRAM)
          </h2>

          <Accordion type="single" collapsible className="space-y-4">
            <AccordionItem value="item-1" className="border border-red-600/20 rounded-lg px-4 bg-black/20">
              <AccordionTrigger className="hover:text-red-400">【2.1】ОСНОВА ОСНОВ: ПРЕДАННОСТЬ ПРОЕКТУ</AccordionTrigger>
              <AccordionContent className="space-y-3 text-gray-300 pt-4">
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Запрещено состоять одновременно в 2 и более хаусах/командах/гильдиях, чья деятельность пересекается с нашей.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: БАН.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Выход из основного хауса проекта — окончательный. Возврат обсуждается только в исключительных случаях с Владельцем.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание за самовольный выход с целью уйти в другую команду: БАН.</p>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2" className="border border-red-600/20 rounded-lg px-4 bg-black/20">
              <AccordionTrigger className="hover:text-red-400">【2.2】КОНТЕНТ И ПОВЕДЕНИЕ В ЧАТЕ</AccordionTrigger>
              <AccordionContent className="space-y-3 text-gray-300 pt-4">
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Спам: flood сообщениями, стикерами, гифками, командами.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 2 недели.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Запрещенный контент: материалы 18+, шок-контент (жестокость, кровь и т.п.), эротический RP.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 3 недели.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Пропаганда или обсуждение наркотических веществ, суицида и т.д.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Мут 1-2 часа.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Создание помех в голосовых звонках: громкие посторонние звуки, намеренный скример, фоновый шум.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 1 неделю.</p>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3" className="border border-red-600/20 rounded-lg px-4 bg-black/20">
              <AccordionTrigger className="hover:text-red-400">【2.3】УВАЖЕНИЕ И РАЗРЕШЕНИЕ КОНФЛИКТОВ</AccordionTrigger>
              <AccordionContent className="space-y-3 text-gray-300 pt-4">
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Прямые оскорбления, унижения, травля.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: 2 Варна (сроком на 1 месяц).</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Игнорирование команды /stop.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Мут 1-2 часа + Варн на 3 недели.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Вынос конфликтов на публику вместо решения в ЛС или с администрацией.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 3 недели + Мут 1-2 часа.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Клевета, ложные обвинения в адрес участников или администрации.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: 2 Варна (сроком на 1 месяц).</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Обсуждение политики, религии, национальных вопросов. Это темы, ведущие к ссорам.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Мут 1-2 часа.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Навязчивое поведение, приставания, нежелательное внимание после просьбы остановиться.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 3 недели + Мут 1-3 часа.</p>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-4" className="border border-red-600/20 rounded-lg px-4 bg-black/20">
              <AccordionTrigger className="hover:text-red-400">【2.4】ПРОЧИЕ ВАЖНЫЕ МОМЕНТЫ</AccordionTrigger>
              <AccordionContent className="space-y-3 text-gray-300 pt-4">
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Доступ к играм в слова имеют только участники, находящиеся в проекте не меньше месяца и имеющие более 1000 сообщений в чате за всё время.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание за нарушение: Предупреждение → Мут 1-2 часа.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Реклама любых сторонних проектов, каналов, чатов, социальных сетей без предварительного согласования с Администрацией.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 3 недели.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Основной язык общения в чате — русский. Использование других языков допустимо, если это не мешает пониманию.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Предупреждение → Мут 1-2 часа.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Публичные просьбы выдать мут или варн себе или другим.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Выдается то, о чем просили.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Сообщения "лесенкой" (каждое слово с новой строки) для привлечения внимания.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 3 недели + Мут 1 час.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Навязчивые обращения и приставания к Администрации по любым вопросам, особенно в ЛС.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 4 недели.</p>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </Card>

        {/* Сервер Minecraft */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Server className="w-6 h-6 text-red-600" />
            СЕРВЕР MINECRAFT
          </h2>

          <Accordion type="single" collapsible className="space-y-4">
            <AccordionItem value="server-1" className="border border-red-600/20 rounded-lg px-4 bg-black/20">
              <AccordionTrigger className="hover:text-red-400">【3.1】СОБСТВЕННОСТЬ И БЕЗОПАСНОСТЬ</AccordionTrigger>
              <AccordionContent className="space-y-3 text-gray-300 pt-4">
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Кража вещей из сундуков, гриферинг (порча) чужих построек без разрешения.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 6 недель или БАН (в зависимости от масштаба ущерба).</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Использование читов, дюпов, эксплуатация багов для получения преимущества.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: БАН без возможности обжалования.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Создание неприемлемых построек (объекты, оскорбляющие чувства других, непристойности).</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 3 недели + снос постройки.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Сокрытие информации о читерах или пособничество им.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: 2 Варна (сроком на 1 месяц).</p>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="server-2" className="border border-red-600/20 rounded-lg px-4 bg-black/20">
              <AccordionTrigger className="hover:text-red-400">【3.2】ПРАВИЛА PVP</AccordionTrigger>
              <AccordionContent className="space-y-3 text-gray-300 pt-4">
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Нападение на другого игрока без его явного согласия.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 2 недели + компенсация урона/вещей.</p>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="server-3" className="border border-red-600/20 rounded-lg px-4 bg-black/20">
              <AccordionTrigger className="hover:text-red-400">【3.3】ВЗАИМОДЕЙСТВИЕ С АДМИНИСТРАЦИЕЙ СЕРВЕРА</AccordionTrigger>
              <AccordionContent className="space-y-3 text-gray-300 pt-4">
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p className="mb-2">· ╰─ Выпрашивание привилегий, предметов, телепортов и т.д.</p>
                  <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 2 недели.</p>
                </div>
                <div className="p-3 bg-red-950/10 rounded-lg">
                  <p>· ╰─ Утеря вещей из-за лагов, отката или смерти по вине сбоя рассматривается индивидуально при наличии видеодоказательств. "На слово" возврата нет.</p>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </Card>

        {/* Съемки и ивенты */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Film className="w-6 h-6 text-red-600" />
            СЪЕМКИ И ИВЕНТЫ
          </h2>
          <div className="space-y-3">
            <div className="p-3 bg-red-950/10 rounded-lg">
              <p className="text-gray-300 mb-2">· ╰─ Намеренное препятствование процессу съемки или проведению ивента.</p>
              <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 3 недели.</p>
            </div>
            <div className="p-3 bg-red-950/10 rounded-lg">
              <p className="text-gray-300 mb-2">· ╰─ Порча декораций, битье NPC, ломание механизмов, созданных для ивента.</p>
              <p className="text-sm text-red-400 ml-4">✎ Наказание: 2 Варна (сроком на 5 недель) + компенсация ресурсов.</p>
            </div>
            <div className="p-3 bg-red-950/10 rounded-lg">
              <p className="text-gray-300 mb-2">· ╰─ Перебивание ивентолога или других участников во время отыгрыша или объяснений.</p>
              <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 3 недели.</p>
            </div>
            <div className="p-3 bg-red-950/10 rounded-lg">
              <p className="text-gray-300 mb-2">· ╰─ Действия, ломающие сюжет или мешающие его прохождению (метагейминг, неуместные действия).</p>
              <p className="text-sm text-red-400 ml-4">✎ Наказание: 2 Варна (сроком на 2 недели).</p>
            </div>
            <div className="p-3 bg-red-950/10 rounded-lg">
              <p className="text-gray-300 mb-2">· ╰─ Публичное оскорбление сценария, сюжета или работы ивентмейкера.</p>
              <p className="text-sm text-red-400 ml-4">✎ Наказание: Варн на 4 недели или БАН.</p>
            </div>
            <div className="p-3 bg-black/20 rounded-lg">
              <p className="text-gray-300">· ╰─ Ивентмейкер имеет право действовать по ситуации для сохранения атмосферы и порядка, даже если конкретное действие не прописано в правилах.</p>
            </div>
          </div>
        </Card>

        {/* Полномочия */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-red-950/30 to-black/40 border-red-600/30">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Users className="w-6 h-6 text-red-600" />
            ПОЛНОМОЧИЯ АДМИНИСТРАЦИИ
          </h2>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
              <span className="text-red-600">·</span>
              <p className="text-gray-300">╰─ Администрация оставляет за собой право выдавать наказания (Варн, Мут, Бан) на свое усмотрение в рамках данных правил.</p>
            </div>
            <div className="flex items-start gap-3 p-3 bg-yellow-950/10 rounded-lg border-l-4 border-yellow-500">
              <span className="text-red-600">·</span>
              <p className="text-yellow-200">╰─ Решения Администрации и Владельца проекта являются ОКОНЧАТЕЛЬНЫМИ и НЕОСПОРИМЫМИ. Все спорные ситуации обсуждаются в уважительной форме после отбытия наказания.</p>
            </div>
          </div>
        </Card>

        {/* Заключение */}
        <Card className="p-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20 text-center">
          <FeatherIcon className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <p className="text-xl text-gray-300 mb-4">
            Спасибо, что вы с нами!
          </p>
          <p className="text-gray-400">
            Соблюдая эти правила, вы помогаете сделать PenTime лучше для всех
          </p>
        </Card>
      </div>
    </div>
  );
}
import { Sparkles, ShoppingBag, Server } from 'lucide-react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { Button } from '@/app/components/ui/button';
import { Card } from '@/app/components/ui/card';

interface CallToActionProps {
  onNavigate: (page: string) => void;
}

export function CallToAction({ onNavigate }: CallToActionProps) {
  return (
    <section className="py-16 px-4">
      <div className="max-w-6xl mx-auto">
        <Card className="relative overflow-hidden bg-gradient-to-br from-red-950/30 via-black/40 to-red-950/30 border-red-600/30 p-12">
          {/* Декоративные элементы */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-red-600 rounded-full blur-[120px] opacity-20" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-white rounded-full blur-[120px] opacity-10" />

          <div className="relative z-10">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <FeatherIcon className="w-16 h-16 text-red-600 animate-pulse" />
                <div className="absolute inset-0 bg-red-600/30 blur-xl" />
              </div>
            </div>

            <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
              Готовы начать свое приключение?
            </h2>
            
            <p className="text-xl text-gray-300 text-center mb-8 max-w-2xl mx-auto">
              Присоединяйтесь к сообществу PenTime и станьте частью нашей истории
            </p>

            <div className="flex flex-wrap gap-4 justify-center">
              <Button
                onClick={() => onNavigate('shop')}
                className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 px-8 py-6 text-lg"
              >
                <ShoppingBag className="w-5 h-5 mr-2" />
                Посетить магазин
              </Button>
              
              <Button
                onClick={() => onNavigate('info')}
                variant="outline"
                className="border-red-600/50 text-white hover:bg-red-600/10 px-8 py-6 text-lg"
              >
                <Server className="w-5 h-5 mr-2" />
                Как начать играть
              </Button>
            </div>

            {/* Особенности */}
            <div className="grid md:grid-cols-3 gap-6 mt-12">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-red-600/10 rounded-full mb-3">
                  <Sparkles className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="font-semibold mb-1">Уникальные режимы</h3>
                <p className="text-sm text-gray-400">Креатив и выживание</p>
              </div>

              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-red-600/10 rounded-full mb-3">
                  <FeatherIcon className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="font-semibold mb-1">Живое комьюнити</h3>
                <p className="text-sm text-gray-400">Тысячи активных игроков</p>
              </div>

              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-red-600/10 rounded-full mb-3">
                  <Server className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="font-semibold mb-1">24/7 онлайн</h3>
                <p className="text-sm text-gray-400">Стабильная работа</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}

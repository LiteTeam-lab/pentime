import { useState } from 'react';
import { ShoppingCart, Crown, Wrench, Sparkles, Check, CreditCard, UserX, Tag } from 'lucide-react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { Card } from '@/app/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/app/components/ui/dialog';
import { Button } from '@/app/components/ui/button';
import { toast } from 'sonner';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

interface ShopItem {
  id: string;
  name: string;
  price: number;
  features: string[];
  gradient: string;
  popular?: boolean;
  image?: string;
}

interface UnbanItem {
  id: string;
  name: string;
  price: number;
  description: string;
}

interface DecorItem {
  id: string;
  name: string;
  price: number;
  description: string;
}

interface ShopPageProps {
  onNavigate: (page: string) => void;
}

export function ShopPage({ onNavigate }: ShopPageProps) {
  const [selectedItem, setSelectedItem] = useState<ShopItem | null>(null);
  const [selectedUnban, setSelectedUnban] = useState<UnbanItem | null>(null);
  const [selectedDecor, setSelectedDecor] = useState<DecorItem | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string>('');

  const roles: ShopItem[] = [
    {
      id: 'snovidec',
      name: 'Сновидец',
      price: 19,
      features: [
        'Все доступные команды Оракул',
        'Возможность ставить 1 точку дома /sethome',
        'Возможность отправить запрос телепортации /tpa',
      ],
      gradient: 'from-purple-600 to-blue-600',
      image: 'https://images.unsplash.com/photo-1759663174469-f1e2a7a4bdcb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5lY3JhZnQlMjBjaGFyYWN0ZXIlMjBkcmVhbWVyJTIwZmFudGFzeXxlbnwxfHx8fDE3NzAxNjU0OTd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'providec',
      name: 'Провидец',
      price: 39,
      features: [
        'Все доступные команды предыдущих рангов',
        'Игнорировать игрока /ignore',
        'Анонимное сообщение в чат /anon',
        'Возможность ставить 2 точки дома /sethome',
        'Отправить запрос на телепортацию к себе /tpahere',
        'Открыть верстак /craft',
      ],
      gradient: 'from-blue-600 to-cyan-600',
      popular: true,
      image: 'https://images.unsplash.com/photo-1760578360025-54444d691eb3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5lY3JhZnQlMjBjaGFyYWN0ZXIlMjB3aXphcmQlMjBwdXJwbGV8ZW58MXx8fHwxNzcwMTY1NDk3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'manuskript',
      name: 'Манускрипт',
      price: 69,
      features: [
        'Все доступные команды предыдущих рангов',
        'Возможность ставить 4 точки дома /sethome',
        'Установить 2 точки варпа /setwarp',
        'Вылечить себя /heal',
        'Открыть эндерсундук /ec',
      ],
      gradient: 'from-cyan-600 to-teal-600',
      image: 'https://images.unsplash.com/photo-1760114333255-60fec662a268?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5lY3JhZnQlMjBjaGFyYWN0ZXIlMjBtYWdlJTIwYmx1ZXxlbnwxfHx8fDE3NzAxNjU0OTd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'skrizhal',
      name: 'Скрижаль',
      price: 99,
      features: [
        'Все доступные команды предыдущих рангов',
        'Возможность ставить 5 точек дома /sethome',
        'Установить 3 точки варпа /setwarp',
        'Включить полёт /fly',
        'Открыть эндерсундук /ec',
      ],
      gradient: 'from-teal-600 to-green-600',
      image: 'https://images.unsplash.com/photo-1583081274923-57bda8d4a15d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5lY3JhZnQlMjBjaGFyYWN0ZXIlMjBzYWdlJTIwY3lhbnxlbnwxfHx8fDE3NzAxNjU0OTh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'nebozhitel',
      name: 'Небожитель',
      price: 139,
      features: [
        'Все доступные команды предыдущих рангов',
        'Возможность ставить 5 точек дома /sethome',
        'Установить 3 точки варпа /setwarp',
        'Включить полёт /fly',
        'Открыть эндерсундук /ec',
      ],
      gradient: 'from-green-600 to-yellow-600',
      image: 'https://images.unsplash.com/photo-1750711379704-0a8bcfb34f36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5lY3JhZnQlMjBjaGFyYWN0ZXIlMjBrbmlnaHQlMjB5ZWxsb3d8ZW58MXx8fHwxNzcwMTY1NTAxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'hronomant',
      name: 'Хрономант',
      price: 169,
      features: [
        'Все доступные команды предыдущих рангов',
        'Скоро...',
      ],
      gradient: 'from-yellow-600 to-red-600',
      image: 'https://images.unsplash.com/photo-1562230778-25514c8237f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5lY3JhZnQlMjBjaGFyYWN0ZXIlMjBtYXN0ZXIlMjByZWR8ZW58MXx8fHwxNzcwMTY1NDk4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
  ];

  const unbans: UnbanItem[] = [
    {
      id: 'unban-chat',
      name: 'Разбан в чате Telegram',
      price: 199,
      description: 'Снятие бана в общем чате проекта',
    },
    {
      id: 'unban-server',
      name: 'Разбан на сервере Minecraft',
      price: 249,
      description: 'Снятие бана на игровом сервере',
    },
    {
      id: 'unban-full',
      name: 'Полная амнистия',
      price: 499,
      description: 'Снятие бана на сервере и в чате',
    },
  ];

  const decorItems: DecorItem[] = [
    {
      id: 'tag-month',
      name: 'Тег (месяц)',
      price: 99,
      description: 'Персональный тег в чате на 1 месяц',
    },
    {
      id: 'tag-forever',
      name: 'Тег (навсегда)',
      price: 199,
      description: 'Персональный тег в чате навсегда',
    },
  ];

  const handlePurchase = () => {
    if (!selectedItem || !paymentMethod) {
      toast.error('Выберите способ оплаты');
      return;
    }

    toast.success('Переход к оплате...', {
      description: `Покупка: ${selectedItem.name} (${selectedItem.price} ₽)`,
    });

    setTimeout(() => {
      setSelectedItem(null);
      setPaymentMethod('');
    }, 1500);
  };

  const handleUnbanPurchase = () => {
    if (!selectedUnban || !paymentMethod) {
      toast.error('Выберите способ оплаты');
      return;
    }

    toast.success('Переход к оплате...', {
      description: `Покупка: ${selectedUnban.name} (${selectedUnban.price} ₽)`,
    });

    setTimeout(() => {
      setSelectedUnban(null);
      setPaymentMethod('');
    }, 1500);
  };

  const handleDecorPurchase = () => {
    if (!selectedDecor || !paymentMethod) {
      toast.error('Выберите способ оплаты');
      return;
    }

    toast.success('Переход к оплате...', {
      description: `Покупка: ${selectedDecor.name} (${selectedDecor.price} ₽)`,
    });

    setTimeout(() => {
      setSelectedDecor(null);
      setPaymentMethod('');
    }, 1500);
  };

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Заголовок */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 flex items-center justify-center gap-3">
            <ShoppingCart className="w-12 h-12 text-red-600" />
            Магазин PenTime
          </h1>
          <p className="text-xl text-gray-400">
            Поддержите проект и получите эксклюзивные преимущества
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent mx-auto mt-6" />
        </div>

        {/* Роли */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <Crown className="w-8 h-8 text-red-600" />
            <h2 className="text-3xl font-bold">Роли</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {roles.map((role) => (
              <Card
                key={role.id}
                className={`relative p-6 bg-gradient-to-br from-black/60 to-red-950/20 border-red-600/20 hover:border-red-600/50 transition-all cursor-pointer group overflow-hidden ${
                  role.popular ? 'ring-2 ring-red-600' : ''
                }`}
                onClick={() => setSelectedItem(role)}
              >
                {/* Популярный бейдж */}
                {role.popular && (
                  <div className="absolute top-4 right-4 px-3 py-1 bg-gradient-to-r from-red-600 to-red-700 rounded-full text-xs font-bold flex items-center gap-1 z-10">
                    <Sparkles className="w-3 h-3" />
                    Популярный
                  </div>
                )}

                {/* Градиентный фон */}
                <div className={`absolute inset-0 bg-gradient-to-br ${role.gradient} opacity-5 group-hover:opacity-10 transition-opacity`} />

                <div className="relative">
                  {/* Место для изображения персонажа */}
                  <div className="relative w-full aspect-square mb-4 bg-gradient-to-br from-black/60 to-red-950/30 border border-red-600/20 rounded-lg overflow-hidden">
                    {role.image ? (
                      <ImageWithFallback
                        src={role.image}
                        alt={role.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <FeatherIcon className="w-16 h-16 text-red-600/30 mx-auto mb-2" />
                          <p className="text-xs text-gray-500">Персонаж роли</p>
                          <p className="text-xs text-gray-600">{role.name}</p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Название и цена */}
                  <h3 className="text-2xl font-bold text-center mb-2">{role.name}</h3>
                  <div className="text-center mb-6">
                    <span className="text-3xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                      {role.price}
                    </span>
                    <span className="text-gray-400 ml-1">₽</span>
                  </div>

                  {/* Особенности */}
                  <ul className="space-y-2 mb-6">
                    {role.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm text-gray-300">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Кнопка покупки */}
                  <Button
                    className={`w-full bg-gradient-to-r ${role.gradient} hover:opacity-90 transition-opacity`}
                    onClick={() => setSelectedItem(role)}
                  >
                    Купить роль
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Амнистия */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <UserX className="w-8 h-8 text-red-600" />
            <h2 className="text-3xl font-bold">Амнистия</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {unbans.map((unban) => (
              <Card
                key={unban.id}
                className="relative p-6 bg-gradient-to-br from-black/60 to-red-950/20 border-red-600/20 hover:border-red-600/50 transition-all cursor-pointer group"
                onClick={() => setSelectedUnban(unban)}
              >
                <div className="relative">
                  <div className="flex justify-center mb-4">
                    <div className="p-4 bg-gradient-to-br from-orange-600 to-red-600 rounded-xl">
                      <UserX className="w-8 h-8 text-white" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-center mb-2">{unban.name}</h3>
                  <div className="text-center mb-4">
                    <span className="text-3xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                      {unban.price}
                    </span>
                    <span className="text-gray-400 ml-1">₽</span>
                  </div>

                  <p className="text-sm text-gray-400 text-center mb-6">{unban.description}</p>

                  <Button
                    className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:opacity-90 transition-opacity"
                    onClick={() => setSelectedUnban(unban)}
                  >
                    Купить амнистию
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          <div className="mt-6 p-4 bg-yellow-950/20 border border-yellow-600/30 rounded-lg">
            <p className="text-sm text-yellow-300 text-center">
              ⚠️ После покупки амнистии рекомендуется ознакомиться с правилами проекта, чтобы избежать повторных нарушений
            </p>
          </div>
        </section>

        {/* Декоративные функции */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <Tag className="w-8 h-8 text-red-600" />
            <h2 className="text-3xl font-bold">Декоративные функции</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {decorItems.map((item) => (
              <Card
                key={item.id}
                className="relative p-6 bg-gradient-to-br from-black/60 to-purple-950/20 border-purple-600/20 hover:border-purple-600/50 transition-all cursor-pointer group"
                onClick={() => setSelectedDecor(item)}
              >
                <div className="relative">
                  <div className="flex justify-center mb-4">
                    <div className="p-4 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl">
                      <Tag className="w-8 h-8 text-white" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-center mb-2">{item.name}</h3>
                  <div className="text-center mb-4">
                    <span className="text-3xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                      {item.price}
                    </span>
                    <span className="text-gray-400 ml-1">₽</span>
                  </div>

                  <p className="text-sm text-gray-400 text-center mb-6">{item.description}</p>

                  <Button
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90 transition-opacity"
                    onClick={() => setSelectedDecor(item)}
                  >
                    Купить тег
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Разработка */}
        <section>
          <div className="flex items-center gap-3 mb-8">
            <Wrench className="w-8 h-8 text-red-600" />
            <h2 className="text-3xl font-bold">Разработка</h2>
          </div>

          <Card className="p-12 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20 text-center">
            <Wrench className="w-16 h-16 text-red-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-2">Скоро здесь появятся новые товары</h3>
            <p className="text-gray-400">
              Мы работаем над добавлением новых интересных предложений для вас
            </p>
          </Card>
        </section>
      </div>

      {/* Модальное окно покупки роли */}
      <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
        <DialogContent className="bg-gradient-to-br from-black via-red-950/20 to-black border-red-600/50 max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedItem && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3 text-xl md:text-2xl">
                  <div className={`p-2 md:p-3 bg-gradient-to-br ${selectedItem.gradient} rounded-lg`}>
                    <FeatherIcon className="w-5 h-5 md:w-6 md:h-6 text-white" />
                  </div>
                  <span className="text-base md:text-2xl">Покупка роли: {selectedItem.name}</span>
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-4 md:space-y-6">
                {/* Информация о товаре */}
                <div className="p-4 md:p-6 bg-red-950/20 rounded-lg border border-red-600/20">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-gray-400 text-sm md:text-base">Цена:</span>
                    <span className="text-2xl md:text-3xl font-bold">{selectedItem.price} ₽</span>
                  </div>
                  <div className="border-t border-red-600/20 pt-4">
                    <p className="text-sm text-gray-400 mb-3">Вы получите:</p>
                    <ul className="space-y-2">
                      {selectedItem.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm">
                          <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Способы оплаты */}
                <div>
                  <h3 className="font-bold mb-3 md:mb-4 flex items-center gap-2 text-sm md:text-base">
                    <CreditCard className="w-4 h-4 md:w-5 md:h-5 text-red-600" />
                    Выберите способ оплаты:
                  </h3>
                  <div className="grid grid-cols-2 gap-2 md:gap-3">
                    {[
                      { id: 'card', name: 'Банковская карта', icon: '💳' },
                      { id: 'sbp', name: 'СБП', icon: '🏦' },
                      { id: 'yoomoney', name: 'ЮMoney', icon: '🟡' },
                      { id: 'qiwi', name: 'QIWI', icon: '🟠' },
                    ].map((method) => (
                      <button
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id)}
                        className={`p-3 md:p-4 rounded-lg border-2 transition-all ${
                          paymentMethod === method.id
                            ? 'border-red-600 bg-red-600/10'
                            : 'border-red-600/20 hover:border-red-600/50'
                        }`}
                      >
                        <div className="text-xl md:text-2xl mb-1">{method.icon}</div>
                        <div className="text-xs md:text-sm">{method.name}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Информация */}
                <div className="p-3 md:p-4 bg-blue-950/20 rounded-lg border border-blue-600/20">
                  <p className="text-xs md:text-sm text-blue-300">
                    ℹ️ После оплаты привилегия активируется автоматически в течение 5 минут
                  </p>
                </div>

                {/* Кнопки */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    onClick={() => setSelectedItem(null)}
                    variant="outline"
                    className="flex-1 border-red-600/50"
                  >
                    Отмена
                  </Button>
                  <Button
                    onClick={handlePurchase}
                    disabled={!paymentMethod}
                    className={`flex-1 bg-gradient-to-r ${selectedItem.gradient} hover:opacity-90`}
                  >
                    <CreditCard className="w-4 h-4 mr-2" />
                    Перейти к оплате
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Модальное окно покупки амнистии */}
      <Dialog open={!!selectedUnban} onOpenChange={() => setSelectedUnban(null)}>
        <DialogContent className="bg-gradient-to-br from-black via-red-950/20 to-black border-red-600/50 max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedUnban && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3 text-xl md:text-2xl">
                  <div className="p-2 md:p-3 bg-gradient-to-br from-orange-600 to-red-600 rounded-lg">
                    <UserX className="w-5 h-5 md:w-6 md:h-6 text-white" />
                  </div>
                  <span className="text-base md:text-2xl">{selectedUnban.name}</span>
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-4 md:space-y-6">
                {/* Информация о товаре */}
                <div className="p-4 md:p-6 bg-red-950/20 rounded-lg border border-red-600/20">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-gray-400 text-sm md:text-base">Цена:</span>
                    <span className="text-2xl md:text-3xl font-bold">{selectedUnban.price} ₽</span>
                  </div>
                  <div className="border-t border-red-600/20 pt-4">
                    <p className="text-sm text-gray-300">{selectedUnban.description}</p>
                  </div>
                </div>

                {/* Способы оплаты */}
                <div>
                  <h3 className="font-bold mb-3 md:mb-4 flex items-center gap-2 text-sm md:text-base">
                    <CreditCard className="w-4 h-4 md:w-5 md:h-5 text-red-600" />
                    Выберите способ оплаты:
                  </h3>
                  <div className="grid grid-cols-2 gap-2 md:gap-3">
                    {[
                      { id: 'card', name: 'Банковская карта', icon: '💳' },
                      { id: 'sbp', name: 'СБП', icon: '🏦' },
                      { id: 'yoomoney', name: 'ЮMoney', icon: '🟡' },
                      { id: 'qiwi', name: 'QIWI', icon: '🟠' },
                    ].map((method) => (
                      <button
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id)}
                        className={`p-3 md:p-4 rounded-lg border-2 transition-all ${
                          paymentMethod === method.id
                            ? 'border-red-600 bg-red-600/10'
                            : 'border-red-600/20 hover:border-red-600/50'
                        }`}
                      >
                        <div className="text-xl md:text-2xl mb-1">{method.icon}</div>
                        <div className="text-xs md:text-sm">{method.name}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Предупреждение */}
                <div className="p-3 md:p-4 bg-yellow-950/20 rounded-lg border border-yellow-600/30">
                  <p className="text-xs md:text-sm text-yellow-300">
                    ⚠️ Перед покупкой убедитесь, что вы готовы соблюдать правила проекта. Повторные нарушения могут привести к постоянному бану.
                  </p>
                </div>

                {/* Информация */}
                <div className="p-3 md:p-4 bg-blue-950/20 rounded-lg border border-blue-600/20">
                  <p className="text-xs md:text-sm text-blue-300">
                    ℹ️ После оплаты амнистия будет рассмотрена администрацией в течение 24 часов
                  </p>
                </div>

                {/* Кнопки */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    onClick={() => setSelectedUnban(null)}
                    variant="outline"
                    className="flex-1 border-red-600/50"
                  >
                    Отмена
                  </Button>
                  <Button
                    onClick={handleUnbanPurchase}
                    disabled={!paymentMethod}
                    className="flex-1 bg-gradient-to-r from-orange-600 to-red-600 hover:opacity-90"
                  >
                    <CreditCard className="w-4 h-4 mr-2" />
                    Перейти к оплате
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Модальное окно покупки декоративных функций */}
      <Dialog open={!!selectedDecor} onOpenChange={() => setSelectedDecor(null)}>
        <DialogContent className="bg-gradient-to-br from-black via-purple-950/20 to-black border-purple-600/50 max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedDecor && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3 text-xl md:text-2xl">
                  <div className="p-2 md:p-3 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg">
                    <Tag className="w-5 h-5 md:w-6 md:h-6 text-white" />
                  </div>
                  <span className="text-base md:text-2xl">{selectedDecor.name}</span>
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-4 md:space-y-6">
                {/* Информация о товаре */}
                <div className="p-4 md:p-6 bg-purple-950/20 rounded-lg border border-purple-600/20">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-gray-400 text-sm md:text-base">Цена:</span>
                    <span className="text-2xl md:text-3xl font-bold">{selectedDecor.price} ₽</span>
                  </div>
                  <div className="border-t border-purple-600/20 pt-4">
                    <p className="text-sm text-gray-300">{selectedDecor.description}</p>
                  </div>
                </div>

                {/* Способы оплаты */}
                <div>
                  <h3 className="font-bold mb-3 md:mb-4 flex items-center gap-2 text-sm md:text-base">
                    <CreditCard className="w-4 h-4 md:w-5 md:h-5 text-purple-600" />
                    Выберите способ оплаты:
                  </h3>
                  <div className="grid grid-cols-2 gap-2 md:gap-3">
                    {[
                      { id: 'card', name: 'Банковская карта', icon: '💳' },
                      { id: 'sbp', name: 'СБП', icon: '🏦' },
                      { id: 'yoomoney', name: 'ЮMoney', icon: '🟡' },
                      { id: 'qiwi', name: 'QIWI', icon: '🟠' },
                    ].map((method) => (
                      <button
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id)}
                        className={`p-3 md:p-4 rounded-lg border-2 transition-all ${
                          paymentMethod === method.id
                            ? 'border-purple-600 bg-purple-600/10'
                            : 'border-purple-600/20 hover:border-purple-600/50'
                        }`}
                      >
                        <div className="text-xl md:text-2xl mb-1">{method.icon}</div>
                        <div className="text-xs md:text-sm">{method.name}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Информация */}
                <div className="p-3 md:p-4 bg-blue-950/20 rounded-lg border border-blue-600/20">
                  <p className="text-xs md:text-sm text-blue-300">
                    ℹ️ После оплаты свяжитесь с администрацией для настройки вашего тега
                  </p>
                </div>

                {/* Кнопки */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    onClick={() => setSelectedDecor(null)}
                    variant="outline"
                    className="flex-1 border-purple-600/50"
                  >
                    Отмена
                  </Button>
                  <Button
                    onClick={handleDecorPurchase}
                    disabled={!paymentMethod}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90"
                  >
                    <CreditCard className="w-4 h-4 mr-2" />
                    Перейти к оплате
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { Users, Sparkles, Gamepad2, Shield, MessageSquare, Globe } from 'lucide-react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { ParticleBackground } from '@/app/components/ParticleBackground';
import { Button } from '@/app/components/ui/button';
import { Card } from '@/app/components/ui/card';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const [onlineCount, setOnlineCount] = useState(0);

  useEffect(() => {
    // Симуляция онлайн счетчика
    const targetOnline = Math.floor(Math.random() * 50) + 30;
    let current = 0;
    const interval = setInterval(() => {
      if (current < targetOnline) {
        current += 1;
        setOnlineCount(current);
      } else {
        clearInterval(interval);
      }
    }, 30);

    return () => clearInterval(interval);
  }, []);

  const features = [
    {
      icon: MessageSquare,
      title: 'Ежедневный актив в чате',
      description: 'Здесь вас ждут люди с самыми разными интересами. Общайтесь, делитесь новостями и находите новых друзей в уютном и живом комьюнити.',
    },
    {
      icon: Globe,
      title: 'Кастомный мир',
      description: 'Новые биомы, уникальные локации и прекрасная территория для исследования. Отправляйтесь в путешествие, чтобы увидеть то, чего нет в обычном мире.',
    },
    {
      icon: Gamepad2,
      title: 'Интерактив на выживании',
      description: 'На выживании вас ждёт глубокая экономика: магазины, работы, система званий, аукционы, квесты и мероприятия. Развивайтесь и становитесь лучшим!',
    },
    {
      icon: Sparkles,
      title: 'Интерактивы на креативе',
      description: 'На креатив-сервере регулярно проводятся ивенты и мини-игры: психологические «Мафия» и «Бункер», квизы, строй-баттлы и многое другое.',
    },
    {
      icon: Shield,
      title: 'Ваше мнение важно',
      description: 'Вы можете влиять на проект! Пишите предложения по улучшению, участвуйте в анонимных опросах о сервере, хаусе и будущих обновлениях.',
    },
    {
      icon: Users,
      title: 'Единство режимов',
      description: 'Наш проект — это единая экосистема. Достижения, валюта или привилегии могут быть связаны между режимами. Играйте так, как нравится вам!',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero секция */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Анимированный фон */}
        <div className="absolute inset-0 bg-gradient-to-br from-black via-red-950/20 to-black">
          <ParticleBackground />
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-600 rounded-full blur-[120px] animate-pulse" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-white rounded-full blur-[120px] animate-pulse delay-1000" />
          </div>
        </div>

        {/* Контент */}
        <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
          <div className="mb-8 flex justify-center">
            <FeatherIcon variant="animated" className="w-24 h-24 text-red-600" />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white via-red-500 to-white bg-clip-text text-transparent">
              PenTime
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-4">
            Больше, чем мир. Целая вселенная.
          </p>
          
          <p className="text-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            Мы создаем сообщество энтузиастов, где каждый игрок может реализовать свои идеи, найти друзей и получить незабываемый опыт.
          </p>

          {/* Онлайн счетчик */}
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-red-600/20 to-white/10 border border-red-600/30 rounded-full mb-8">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
            <span className="text-white font-semibold">
              Онлайн: {onlineCount} игроков
            </span>
          </div>

          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              onClick={() => onNavigate('shop')}
              className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white px-8 py-6 text-lg"
            >
              <FeatherIcon className="w-5 h-5 mr-2" />
              Купить донат
            </Button>
            <Button
              onClick={() => onNavigate('about')}
              variant="outline"
              className="border-red-600/50 text-white hover:bg-red-600/10 px-8 py-6 text-lg"
            >
              Подробнее о проекте
            </Button>
          </div>
        </div>

        {/* Стрелка вниз */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-8 h-12 border-2 border-red-600 rounded-full flex items-end justify-center pb-2">
            <div className="w-1.5 h-3 bg-red-600 rounded-full" />
          </div>
        </div>
      </section>

      {/* О проекте */}
      <section className="py-20 px-4 bg-gradient-to-b from-black to-red-950/10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 flex items-center justify-center gap-3">
              <FeatherIcon className="w-10 h-10 text-red-600" />
              О проекте
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card
                  key={index}
                  className="p-6 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20 hover:border-red-600/50 transition-all hover:scale-105 cursor-pointer group"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-red-600/10 rounded-lg group-hover:bg-red-600/20 transition-colors">
                      <Icon className="w-6 h-6 text-red-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-2 text-white">{feature.title}</h3>
                      <p className="text-sm text-gray-400">{feature.description}</p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Наша миссия */}
      <section className="py-20 px-4 bg-gradient-to-b from-red-950/10 to-black">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-8">Наша миссия</h2>
          <p className="text-lg text-gray-300 leading-relaxed">
            PenTime — это больше, чем просто Minecraft-сервер. Мы создаем сообщество энтузиастов, 
            где каждый игрок может реализовать свои идеи, найти друзей и получить незабываемый опыт. 
            Наша команда постоянно работает над новыми обновлениями, плагинами и событиями, 
            чтобы игра оставалась интересной и увлекательной.
          </p>
        </div>
      </section>
    </div>
  );
}
import { Crown, Shield, Users, Wrench, Palette, Video, FileText, Star } from 'lucide-react';
import { FeatherIcon } from '@/app/components/FeatherIcon';
import { Card } from '@/app/components/ui/card';

export function AdminPage() {
  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Заголовок */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 flex items-center justify-center gap-3">
            <Shield className="w-12 h-12 text-red-600" />
            Администрация проекта
          </h1>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent mx-auto" />
        </div>

        {/* Владелец проекта */}
        <Card className="p-8 mb-12 bg-gradient-to-br from-red-950/30 to-black/40 border-red-600/50 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 to-transparent" />
          <div className="relative">
            <div className="flex items-center gap-3 mb-8">
              <Crown className="w-8 h-8 text-red-600" />
              <h2 className="text-3xl font-bold">Владелец проекта</h2>
            </div>

            <div className="flex flex-col md:flex-row items-center gap-8">
              {/* Перо с короной вместо фото */}
              <div className="relative w-48 h-48 md:w-64 md:h-64 flex-shrink-0">
                <div className="absolute inset-0 bg-gradient-to-br from-red-600/20 to-black/40 rounded-lg border-2 border-red-600/50 flex items-center justify-center">
                  <div className="relative">
                    <FeatherIcon className="w-32 h-32 md:w-40 md:h-40 text-red-600" />
                    <Crown className="w-16 h-16 md:w-20 md:h-20 text-yellow-500 absolute -top-6 -right-6 md:-top-8 md:-right-8 animate-pulse" />
                  </div>
                </div>
              </div>

              {/* Информация */}
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-3xl font-bold mb-4 bg-gradient-to-r from-white via-red-400 to-white bg-clip-text text-transparent">
                  Кровавая Дарнени
                </h3>
                <div className="space-y-3 text-gray-300">
                  <div className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
                    <p><strong>Подчинение:</strong> Никому.</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
                    <p><strong>Суть:</strong> Стратег, верховный главнокомандующий, гарант Кодекса и финальный арбитр.</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
                    <p><strong>Полномочия:</strong> Абсолютная власть над всеми аспектами проекта.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Описание иерархии */}
        <Card className="p-8 mb-12 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
          <div className="flex items-center gap-3 mb-6">
            <FeatherIcon className="w-6 h-6 text-red-600" />
            <h2 className="text-2xl font-bold">О нашей администрации</h2>
          </div>
          <div className="space-y-4 text-gray-300">
            <p className="leading-relaxed">
              Работа в администрации PenTime — это не про должность, а про ответственность. Мы ищем людей, которые готовы 
              вкладывать время и силы в развитие проекта, поддерживать порядок и создавать атмосферу, в которой каждый 
              чувствует себя частью большой семьи.
            </p>
            <p className="leading-relaxed">
              Высокие роли доступны лишь за особые заслуги и помощь в администрации. Мы ценим штатное выполнение обязанностей, 
              инициативность и преданность проекту. Всяких шалопаев мы не берём — только тех, кто действительно готов работать 
              ради общего дела.
            </p>
            <p className="leading-relaxed">
              Сначала можно подать только на первоначальные должности. Карьерный рост возможен, но только для тех, кто 
              действительно проявил себя и заслужил доверие команды.
            </p>
          </div>
        </Card>

        {/* Уровень 1: Высшие руководители */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-red-950/20 to-black/40 border-red-600/20">
          <div className="flex items-center gap-3 mb-6">
            <Crown className="w-7 h-7 text-yellow-500" />
            <h2 className="text-2xl font-bold">УРОВЕНЬ 1: Высшие руководители</h2>
          </div>
          <p className="text-sm text-gray-400 mb-6">Подчиняются напрямую Владельцу</p>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Судья */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20">
              <div className="flex items-center gap-3 mb-4">
                <Shield className="w-6 h-6 text-blue-500" />
                <h3 className="text-xl font-bold">Судья</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Верховный арбитр</p>
              <p className="text-gray-300 text-sm mb-3">
                Высшая судебная инстанция. Гарант законности, справедливости и соблюдения Правил проекта.
              </p>
              <div className="text-xs text-gray-400 space-y-1">
                <p>• Рассмотрение апелляций</p>
                <p>• Контроль модерации</p>
                <p>• Разработка регламентов</p>
              </div>
            </div>

            {/* Сенатор */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20">
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-6 h-6 text-purple-500" />
                <h3 className="text-xl font-bold">Сенатор</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Глава по работе с сообществом</p>
              <p className="text-gray-300 text-sm mb-3">
                Верховный представитель, защитник интересов и «голос» сообщества внутри администрации.
              </p>
              <div className="text-xs text-gray-400 space-y-1">
                <p>• Отчёты о настроениях</p>
                <p>• Организация активностей</p>
                <p>• Координация наставников</p>
              </div>
            </div>

            {/* Технический директор */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20">
              <div className="flex items-center gap-3 mb-4">
                <Wrench className="w-6 h-6 text-green-500" />
                <h3 className="text-xl font-bold">Технический директор</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Глава технического отдела</p>
              <p className="text-gray-300 text-sm mb-3">
                Полный владелец всей технической инфраструктуры проекта. Отвечает за «железо» и его стабильность.
              </p>
              <div className="text-xs text-gray-400 space-y-1">
                <p>• Стабильность серверов</p>
                <p>• Устранение сбоев</p>
                <p>• Кибербезопасность</p>
              </div>
            </div>

            {/* Глава контента */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20">
              <div className="flex items-center gap-3 mb-4">
                <Palette className="w-6 h-6 text-pink-500" />
                <h3 className="text-xl font-bold">Глава контента и развития</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Руководитель медиа-направления</p>
              <p className="text-gray-300 text-sm mb-3">
                Вдохновитель публичного образа проекта. Отвечает за контент-стратегию и медиа-присутствие.
              </p>
              <div className="text-xs text-gray-400 space-y-1">
                <p>• Контент-планы</p>
                <p>• Управление медиа-отделом</p>
                <p>• Бренд-аккаунты</p>
              </div>
            </div>

            {/* Руководитель по привлечению */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20">
              <div className="flex items-center gap-3 mb-4">
                <Star className="w-6 h-6 text-orange-500" />
                <h3 className="text-xl font-bold">Руководитель по привлечению игроков</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">PR/Маркетинг</p>
              <p className="text-gray-300 text-sm mb-3">
                Стратег роста аудитории. Отвечает за внешнее позиционирование и постоянный приток новых игроков.
              </p>
              <div className="text-xs text-gray-400 space-y-1">
                <p>• Маркетинговая стратегия</p>
                <p>• Работа с партнёрами</p>
                <p>• Анализ воронки привлечения</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Начальные должности */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-black/40 to-red-950/20 border-red-600/20">
          <div className="flex items-center gap-3 mb-6">
            <Users className="w-7 h-7 text-red-600" />
            <h2 className="text-2xl font-bold">Начальные должности</h2>
          </div>
          <p className="text-gray-300 mb-6">
            Эти роли доступны для подачи заявок. Начните свой путь в администрации PenTime с одной из этих позиций:
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Модератор */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20 hover:border-red-600/50 transition-all">
              <div className="flex items-center gap-3 mb-3">
                <Shield className="w-5 h-5 text-blue-400" />
                <h3 className="text-lg font-bold">Модератор-дежурный</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Подчинение: Судья</p>
              <p className="text-gray-300 text-sm">
                «Полицейский» в текстовых и голосовых чатах. Работает строго по графику и регламенту.
              </p>
            </div>

            {/* Инспектор */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20 hover:border-red-600/50 transition-all">
              <div className="flex items-center gap-3 mb-3">
                <Shield className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg font-bold">Инспектор сервера</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Подчинение: Судья</p>
              <p className="text-gray-300 text-sm">
                Полевой оперативник и следователь в игровом мире Minecraft.
              </p>
            </div>

            {/* Наставник */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20 hover:border-red-600/50 transition-all">
              <div className="flex items-center gap-3 mb-3">
                <Users className="w-5 h-5 text-green-400" />
                <h3 className="text-lg font-bold">Наставник</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Подчинение: Сенатор</p>
              <p className="text-gray-300 text-sm">
                Проводник для новых игроков. Помощь в адаптации и контроль испытательного срока.
              </p>
            </div>

            {/* Ивент-менеджер */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20 hover:border-red-600/50 transition-all">
              <div className="flex items-center gap-3 mb-3">
                <Star className="w-5 h-5 text-yellow-400" />
                <h3 className="text-lg font-bold">Ивент-менеджер</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Подчинение: Сенатор</p>
              <p className="text-gray-300 text-sm">
                Организатор мероприятий. Полный цикл от идеи до проведения и отчёта.
              </p>
            </div>

            {/* Билдер */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20 hover:border-red-600/50 transition-all">
              <div className="flex items-center gap-3 mb-3">
                <Wrench className="w-5 h-5 text-orange-400" />
                <h3 className="text-lg font-bold">Билдер-строитель</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Подчинение: Технический директор</p>
              <p className="text-gray-300 text-sm">
                Исполнитель строительных работ. Создание построек по готовым чертежам.
              </p>
            </div>

            {/* Дизайнер */}
            <div className="p-6 bg-black/30 rounded-lg border border-red-600/20 hover:border-red-600/50 transition-all">
              <div className="flex items-center gap-3 mb-3">
                <Palette className="w-5 h-5 text-pink-400" />
                <h3 className="text-lg font-bold">Дизайнер-оформитель</h3>
              </div>
              <p className="text-sm text-gray-400 mb-3">Подчинение: Глава контента</p>
              <p className="text-gray-300 text-sm">
                Исполнитель графических задач. Создание баннеров, постов и оформления.
              </p>
            </div>
          </div>
        </Card>

        {/* Call to Action */}
        <Card className="p-8 bg-gradient-to-br from-red-950/30 to-black/40 border-red-600/50 text-center">
          <FeatherIcon className="w-16 h-16 text-red-600 mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-4">Хочешь стать частью команды?</h2>
          <p className="text-xl text-gray-300 mb-6 max-w-2xl mx-auto">
            Если ты готов взять на себя ответственность, вкладывать время и силы в развитие PenTime, 
            и хочешь помогать создавать лучшее сообщество — мы ждём тебя!
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <a
              href="https://t.me/PenTime_House"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 rounded-lg transition-all text-lg font-semibold"
            >
              Подать заявку в администрацию
            </a>
          </div>
          <p className="text-sm text-gray-500 mt-4">
            Свяжитесь с администрацией проекта для получения дополнительной информации
          </p>
        </Card>
      </div>
    </div>
  );
}
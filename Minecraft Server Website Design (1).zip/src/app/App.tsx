import { useState, useEffect } from 'react';
import { Header } from '@/app/components/Header';
import { Footer } from '@/app/components/Footer';
import { HomePage } from '@/app/components/HomePage';
import { AboutPage } from '@/app/components/AboutPage';
import { ShopPage } from '@/app/components/ShopPage';
import { RulesPage } from '@/app/components/RulesPage';
import { FAQPage } from '@/app/components/FAQPage';
import { InfoPage } from '@/app/components/InfoPage';
import { AdminPage } from '@/app/components/AdminPage';
import { ScrollToTop } from '@/app/components/ScrollToTop';
import { Toaster } from '@/app/components/ui/sonner';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  // Прокрутка вверх при смене страницы
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'about':
        return <AboutPage onNavigate={setCurrentPage} />;
      case 'shop':
        return <ShopPage onNavigate={setCurrentPage} />;
      case 'rules':
        return <RulesPage />;
      case 'faq':
        return <FAQPage />;
      case 'info':
        return <InfoPage />;
      case 'admin':
        return <AdminPage />;
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <Header currentPage={currentPage} onNavigate={setCurrentPage} />

      {/* Main content */}
      <main className="relative">
        {renderPage()}
      </main>

      {/* Footer */}
      <Footer onNavigate={setCurrentPage} />

      {/* Scroll to top button */}
      <ScrollToTop />

      {/* Toast notifications */}
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#1a1a1a',
            border: '1px solid rgba(220, 38, 38, 0.3)',
            color: '#ffffff',
          },
        }}
      />
    </div>
  );
}